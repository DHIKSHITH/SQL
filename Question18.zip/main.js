var mysql = require('mysql');
var readlineSync = require('readline-sync');

var con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
  var type = readlineSync.question('How do you want the data? Monthly or Yearly or Quarterly?');
    if(type === 'Monthly'){
        con.query("SELECT M.App_ID AS 'Application ID',M.App_Description AS 'Application Name' , M.App_Sub_Description AS 'Application Sub Description' , D.month AS 'Month',  F.No_Of_Hours AS 'Downtime Hours',(24-F.No_Of_Hours) as 'Uptime Hours'FROM FACT.Application_Master M JOIN FACT.Application_Down F ON F.App_SK_ID = M.APP_SK_ID JOIN FACT.Date D ON F.Date_SK_ID = D.date_key ORDER BY  D.year,D.month", function (err, result, fields) {
        if (err) throw err;
            console.log(result);
          });
    }else if(type === 'Yearly'){
         con.query("SELECT M.App_ID AS 'Application ID',M.App_Description AS 'Application Name' , M.App_Sub_Description AS 'Application Sub Description' ,D.year AS 'Year',  F.No_Of_Hours AS 'Downtime Hours',(24-F.No_Of_Hours) as 'Uptime Hours'FROM FACT.Application_Master M JOIN FACT.Application_Down F ON F.App_SK_ID = M.APP_SK_ID JOIN FACT.Date D ON F.Date_SK_ID = D.date_key ORDER BY  D.year,D.month", function (err, result, fields) {
        if (err) throw err;
            console.log(result);
        })
    }else if (type === 'Quarterly'){
         con.query("SELECT M.App_ID AS 'Application ID',M.App_Description AS 'Application Name' , M.App_Sub_Description AS 'Application Sub Description' , D.quarter AS 'Quarter',  F.No_Of_Hours AS 'Downtime Hours',(24-F.No_Of_Hours) as 'Uptime Hours'FROM FACT.Application_Master M JOIN FACT.Application_Down F ON F.App_SK_ID = M.APP_SK_ID JOIN FACT.Date D ON F.Date_SK_ID = D.date_key ORDER BY  D.year,D.month", function (err, result, fields) {
    if (err) throw err;
    console.log(result);
    })
    }               
});